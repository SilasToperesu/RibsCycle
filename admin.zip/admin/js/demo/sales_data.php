<?php
include '../RibsCircle_System/db_connect.php';

// Query to fetch monthly sales data
$query = "
    SELECT MONTH(created_at) AS month, SUM(total_price) AS sales 
    FROM invoices 
    WHERE YEAR(created_at) = YEAR(CURRENT_DATE)
    GROUP BY MONTH(created_at)
    ORDER BY month
";

$result = $conn->query($query);

$months = [];
$sales = [];

// Prepare the data
while ($row = $result->fetch_assoc()) {
    $months[] = date("M", mktime(0, 0, 0, $row['month'], 10)); // Get month abbreviation
    $sales[] = (float)$row['sales']; // Convert to float
}

$conn->close();

// Return the data as JSON
echo json_encode(['months' => $months, 'sales' => $sales]);
?>

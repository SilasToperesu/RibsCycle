<?php
include '../RibsCircle_System/db_connect.php';

// Query to fetch monthly revenue (example query, adjust as needed)
$query = "
    SELECT MONTH(created_at) AS month, SUM(total_price) AS revenue 
    FROM invoices 
    WHERE YEAR(created_at) = YEAR(CURRENT_DATE)
    GROUP BY MONTH(created_at)
    ORDER BY month
";

$result = $conn->query($query);

$months = [];
$revenues = [];

// Prepare the data
while ($row = $result->fetch_assoc()) {
    $months[] = date("F", mktime(0, 0, 0, $row['month'], 10)); // Get month name
    $revenues[] = (float)$row['revenue']; // Convert to float
}

$conn->close();

// Return the data as JSON
echo json_encode(['months' => $months, 'revenues' => $revenues]);
?>

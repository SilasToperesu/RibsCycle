<?php
include '../db_connect.php';

// Enable error reporting for debugging (remove or comment out in production)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Fetch total annual sales
$annualSales = 0;
$annualSalesQuery = "SELECT SUM(total_price) AS annual_sales FROM invoices WHERE YEAR(sent_at) = YEAR(CURRENT_DATE)";
$annualSalesResult = $conn->query($annualSalesQuery);
if ($annualSalesResult) {
    $row = $annualSalesResult->fetch_assoc();
    $annualSales = $row['annual_sales'] ? (float)$row['annual_sales'] : 0;
}

// Fetch total amount and count of invoices
$totalQuery = "SELECT SUM(total_price) AS total_amount, COUNT(*) AS item_count FROM invoices";
$totalResult = $conn->query($totalQuery);
$totalRow = $totalResult->fetch_assoc();
$totalAmount = $totalRow['total_amount'] ?? 0;
$itemCount = $totalRow['item_count'] ?? 0;

// Fetch monthly sales data
$monthlySalesQuery = "
    SELECT MONTH(sent_at) AS month, SUM(total_price) AS sales 
    FROM invoices 
    WHERE YEAR(sent_at) = YEAR(CURRENT_DATE)
    GROUP BY MONTH(sent_at)
    ORDER BY month
";
$monthlySalesResult = $conn->query($monthlySalesQuery);
$months = [];
$sales = [];
while ($row = $monthlySalesResult->fetch_assoc()) {
    $months[] = date("M", mktime(0, 0, 0, $row['month'], 10)); // Get month abbreviation
    $sales[] = (float)$row['sales']; // Convert to float
}

// Fetch user data from the database
$userQuery = "SELECT id, username, email, role, LastLogin FROM users";
$userResult = $conn->query($userQuery);

// Fetch user count by role
$roleCountQuery = "SELECT role, COUNT(*) as number_of_users FROM users GROUP BY role";
$roleCountResult = $conn->query($roleCountQuery);

// Fetch product prices
$productQueries = [
    'chicken' => "SELECT price FROM chicken",
    'dagwood' => "SELECT price FROM dagwood",
    'ribs' => "SELECT price FROM ribs"
];
$totalPrices = [];
foreach ($productQueries as $product => $query) {
    $result = $conn->query($query);
    $totalPrices[$product] = 0;
    while ($row = $result->fetch_assoc()) {
        $totalPrices[$product] += $row['price'];
    }
}

// Close the database connection
$conn->close();

// Start HTML output
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8"> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Report</title>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf/2.4.0/jspdf.umd.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jspdf-autotable/3.5.13/jspdf.plugin.autotable.min.js"></script>
    <style>
        /* Basic styles for the page */
        body {
            font-family: Arial, sans-serif;
            margin: 20px;
            color: #333;
        }
        h1 {
            color: #2C3E50;
        }
        h2 {
            color: #2980B9;
        }
        table {
            border-collapse: collapse;
            width: 100%;
            margin: 20px 0;
        }
        th, td {
            border: 1px solid #ccc;
            padding: 8px;
            text-align: left;
        }
        th {
            background-color: #f2f2f2;
        }
        th {
            font-weight: bold;
        }
    </style>
</head>
<body>
    <h1>Ribs Circle Report</h1>

    <h2>Annual Sales</h2>
    <p>Total Annual Sales: R<?php echo number_format($annualSales, 2); ?></p>

    <h2>Total Invoices</h2>
    <p>Total Amount: R<?php echo number_format($totalAmount, 2); ?> </p>
    <p>Total Number Of Orders: <?php echo $itemCount; ?></p>

    <h2>Monthly Sales</h2>
    <table border="1" cellpadding="4" cellspacing="0">
        <thead>
            <tr>
                <th>Month</th>
                <th>Sales (Rands)</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($months as $index => $month): ?>
                <tr>
                    <td><?php echo $month; ?></td>
                    <td><?php echo number_format($sales[$index], 2); ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <h2>User Report</h2>
    <table id="userTable" border="1" cellpadding="4" cellspacing="0">
        <thead>
            <tr>
                <th>ID</th>
                <th>Username</th>
                <th>Email</th>
                <th>Role</th>
                <th>Last Login</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $userResult->fetch_assoc()): ?>
                <tr>
                    <td><?php echo $row['id']; ?></td>
                    <td><?php echo htmlspecialchars($row['username']); ?></td>
                    <td><?php echo htmlspecialchars($row['email']); ?></td>
                    <td><?php echo htmlspecialchars($row['role']); ?></td>
                    <td><?php echo $row['LastLogin'] ? $row['LastLogin'] : 'Never'; ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <h2>User Count by Role</h2>
    <table id="roleCountTable" border="1" cellpadding="4" cellspacing="0">
        <thead>
            <tr>
                <th>Role</th>
                <th>Number of Users</th>
            </tr>
        </thead>
        <tbody>
            <?php while ($row = $roleCountResult->fetch_assoc()): ?>
                <tr>
                    <td><?php echo htmlspecialchars($row['role']); ?></td>
                    <td><?php echo $row['number_of_users']; ?></td>
                </tr>
            <?php endwhile; ?>
        </tbody>
    </table>

    <h2>Total Prices</h2>
    <table id="priceTable" border="1" cellpadding="4" cellspacing="0">
        <thead>
            <tr>
                <th>Product</th>
                <th>Total Price (Rands)</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>Chicken</td>
                <td>R<?php echo number_format($totalPrices['chicken'], 2); ?> </td>
            </tr>
            <tr>
                <td>Dagwood</td>
                <td>R<?php echo number_format($totalPrices['dagwood'], 2); ?> </td>
            </tr>
            <tr>
                <td>Ribs</td>
                <td>R<?php echo number_format($totalPrices['ribs'], 2); ?> </td>
            </tr>
        </tbody>
    </table>

    <button onclick="generatePDF()">Download PDF</button>

    <script>
      
    async function generatePDF() {
        const { jsPDF } = window.jspdf;
        const pdf = new jsPDF();

        // Set title and styles for the report
        pdf.setFont("helvetica", "bold");
        pdf.setFontSize(22);
        pdf.text("Ribs Circle Report", 10, 10);

        // Annual Sales Section
        pdf.setFontSize(10);
        pdf.setFont("helvetica", "normal");
        pdf.text("Annual Sales", 10, 30);
        pdf.text("Total Annual Sales: R" + <?php echo number_format($annualSales, 2, '.', ''); ?>, 10, 40);
        
        // Total Invoices Section
        pdf.text("Total Invoices", 10, 50);
        pdf.text("Total Amount: R" + <?php echo number_format($totalAmount, 2, '.', ''); ?>, 10, 60);
        pdf.text("Total Number Of Orders: " + <?php echo $itemCount; ?>, 10, 70);

        // Monthly Sales Section
        pdf.setFontSize(16);
        pdf.text("Monthly Sales", 10, 80);
        pdf.autoTable({
            head: [['Month', 'Sales (Rands)']],
            body: [
                <?php foreach ($months as $index => $month): ?>
                    ['<?php echo $month; ?>', <?php echo number_format($sales[$index], 2, '.', ''); ?>],
                <?php endforeach; ?>
            ],
            styles: { 
                fillColor: [240, 240, 240], 
                fontSize: 12,
                halign: 'center',
            },
            headStyles: { 
                fillColor: [0, 102, 204], 
                textColor: [255, 255, 255],
                fontSize: 14
            },
            startY: 90,
        });

        // User Report Section
        pdf.addPage();
        pdf.setFontSize(16);
        pdf.text("User Report", 10, 10);
        pdf.autoTable({ 
            html: "#userTable", 
            startY: 20,
            styles: {
                fillColor: [240, 240, 240], 
                fontSize: 12,
                halign: 'center',
            },
            headStyles: { 
                fillColor: [0, 102, 204], 
                textColor: [255, 255, 255],
                fontSize: 14
            }
        });

        // User Count by Role Section
        pdf.addPage();
        pdf.setFontSize(16);
        pdf.text("User Count by Role", 10, 10);
        pdf.autoTable({ 
            html: "#roleCountTable", 
            startY: 20,
            styles: {
                fillColor: [240, 240, 240], 
                fontSize: 12,
                halign: 'center',
            },
            headStyles: { 
                fillColor: [0, 102, 204], 
                textColor: [255, 255, 255],
                fontSize: 14
            }
        });

        // Total Prices Section
        pdf.addPage();
        pdf.setFontSize(16);
        pdf.text("Total Prices", 10, 10);
        pdf.autoTable({
            head: [['Product', 'Total Price (Rands)']],
            body: [
                ['Chicken', 'R' + <?php echo number_format($totalPrices['chicken'], 2, '.', ''); ?>],
                ['Dagwood', 'R' + <?php echo number_format($totalPrices['dagwood'], 2, '.', ''); ?>],
                ['Ribs', 'R' + <?php echo number_format($totalPrices['ribs'], 2, '.', ''); ?>]
            ],
            styles: { 
                fillColor: [240, 240, 240], 
                fontSize: 12,
                halign: 'center',
            },
            headStyles: { 
                fillColor: [0, 102, 204], 
                textColor: [255, 255, 255],
                fontSize: 14
            },
            startY: 20,
        });

        // Save the generated PDF
        pdf.save("UserReport.pdf");
    }
</script>

    
</body>
</html>

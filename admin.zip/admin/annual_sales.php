<?php
include '../db_connect.php';

// Enable error reporting for debugging (remove or comment out in production)
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Prepare the response array
$response = ['annual_sales' => '0.00', 'error' => null];

try {
    // Query to get total annual sales
    $query = "SELECT SUM(total_price) AS annual_sales FROM invoices WHERE YEAR(created_at) = YEAR(CURRENT_DATE)";
    $result = $conn->query($query);

    // Check for query errors
    if (!$result) {
        throw new Exception("Database query failed: " . $conn->error);
    }

    // Fetch the result
    $row = $result->fetch_assoc();
    $annualSales = $row['annual_sales'] ? (float)$row['annual_sales'] : 0;

    // Format the annual sales with thousands separators and two decimal places
    $response['annual_sales'] = number_format($annualSales, 2);

} catch (Exception $e) {
    // Capture any exceptions and store the error message
    $response['error'] = $e->getMessage();
} finally {
    // Close the database connection
    $conn->close();
}

// Return the response as JSON
header('Content-Type: application/json');
echo json_encode($response);
?>

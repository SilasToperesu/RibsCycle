<?php
include '../db_connect.php';

// Query to calculate the total amount and count the number of invoices
$result = $conn->query("SELECT SUM(total_price) AS total_amount, COUNT(*) AS item_count FROM invoices");
$row = $result->fetch_assoc();
$conn->close();

// Return the total amount and item count as JSON
echo json_encode([
    'totalAmount' => $row['total_amount'] ?? 0,
    'itemCount' => $row['item_count'] ?? 0
]);
?>

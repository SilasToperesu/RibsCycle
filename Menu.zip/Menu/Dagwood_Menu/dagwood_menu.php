<?php
include '../../db_connect.php';

// Fetch dagwood items
$dagwood_items = $conn->query("SELECT * FROM dagwood")->fetch_all(MYSQLI_ASSOC);

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Dagwood Menu</title>
    <link rel="stylesheet" href="dagwood.css"> 
    <style>
        body {
            display: flex;
            flex-direction: column;
            align-items: center;
            background-color: darkred;
        }
        .menu {
            display: flex;
            flex-direction: column;
            width: 80%;
            margin: 20px 0;
        }
        .menu-category {
            margin: 20px 0;
        }
        .menu-category h2 {
            text-align: center;
            color: white;
        }
        .menu-items {
            display: flex;
            flex-wrap: wrap;
            justify-content: space-around;
        }
        .menu-item {
            margin: 10px;
            border: 1px solid #ddd;
            border-radius: 8px;
            padding: 10px;
            width: calc(33.33% - 20px); /* 3 items in a row */
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            cursor: pointer; /* Show pointer cursor on hover */
            position: relative; /* Add this for proper positioning of the image */
        }
        .menu-item img {
            width: 250px;
            height: 100px;
            position: absolute;
            top: 2px;
            left: 50%;
            transform: translateX(-50%);
            border: 5px solid white;
            bottom: 10px;
        }
        .menu-item h3, .menu-item p {
            text-align: center;
        }
    </style>
</head>

<body>
    
<?php include '../../header.php'; ?>
<div class="separate">
    <p></p>
</div>

<div class="menu">

    <!-- Dagwood Menu -->
    <div class="menu-category">
        <h2>Dagwood Menu</h2>
        <div class="menu-items">
            <?php foreach ($dagwood_items as $item): ?>
                <div class="menu-item" onclick="addToCart(<?php echo htmlspecialchars(json_encode($item)); ?>)">
                    <img src="../../uploads/<?php echo htmlspecialchars($item['image']); ?>" alt="<?php echo htmlspecialchars($item['description']); ?>">
                    <h3><?php echo htmlspecialchars($item['description']); ?></h3>
                    <p>Price: R<?php echo number_format($item['price'], 2); ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
</div>

<script>
  function addToCart(item) {
    let cart = JSON.parse(localStorage.getItem('cart')) || [];

    // Check if item already exists in cart based on id and description
    const existingItem = cart.find(cartItem => cartItem.id === item.id && cartItem.description === item.description);
    if (existingItem) {
        existingItem.quantity += 1; // Increase the quantity if it already exists
    } else {
        item.quantity = 1; // Set the quantity to 1 if it's a new item
        cart.push(item); // Add the new item to the cart
    }

    // Save the updated cart back to localStorage
    localStorage.setItem('cart', JSON.stringify(cart));

    // Use the updated quantity for the alert message
    const totalQuantity = existingItem ? existingItem.quantity : 1; // 1 for new item
    alert(item.description + ' has been added to your cart. Total quantity: ' + totalQuantity);
    location.reload();
}

</script>

</body>
</html>

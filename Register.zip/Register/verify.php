<?php
// verify.php
include '../db_connect.php';

$successMessage = '';
$errorMessage = '';

if (isset($_GET['code'])) {
    $code = $_GET['code'];

    // Verify the code
    $stmt = $conn->prepare("UPDATE users SET is_verified = 1 WHERE verification_code = ?");
    $stmt->bind_param("s", $code);

    if ($stmt->execute() && $stmt->affected_rows > 0) {
        $successMessage = "Your account has been verified successfully!";
    } else {
        $errorMessage = "Invalid or expired verification code.";
    }

    $stmt->close();
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Verification</title>
</head>
<body>
    <div>
        <?php if (!empty($successMessage)): ?>
            <div><?php echo $successMessage; ?></div>
        <?php endif; ?>
        <?php if (!empty($errorMessage)): ?>
            <div><?php echo $errorMessage; ?></div>
        <?php endif; ?>
    </div>
</body>
</html>
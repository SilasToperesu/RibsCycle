<?php
session_start(); // Start the session
include '../db_connect.php'; // Include database connection file

$errors = [];
$successMessage = '';
$username = $password = $confirmPassword = '';
$borderClass = [
    'username' => '',
    'password' => '',
    'confirmPassword' => ''
];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username']);
    $password = $_POST['password'];
    $confirmPassword = $_POST['confirmPassword'];

    // Validation
    if (empty($username) || strlen($username) < 3) {
        $errors['username'] = "Username must be at least 3 characters long.";
        $borderClass['username'] = 'error';
    }

    if (empty($password) || strlen($password) < 6) {
        $errors['password'] = "Password must be at least 6 characters long.";
        $borderClass['password'] = 'error';
    }

    if ($password !== $confirmPassword) {
        $errors['confirmPassword'] = "Passwords do not match.";
        $borderClass['confirmPassword'] = 'error';
    }

    // Check if username already exists
    $stmt = $conn->prepare("SELECT id FROM admins WHERE username = ?");
    $stmt->bind_param("s", $username);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $errors['username'] = "Username already exists.";
        $borderClass['username'] = 'error';
    }

    $stmt->close();

    // If there are no errors, proceed with registration
    if (empty($errors)) {
        // Hash the password
        $hashed_password = password_hash($password, PASSWORD_DEFAULT);

        // Prepare and bind
        $stmt = $conn->prepare("INSERT INTO admins (username, password) VALUES (?, ?)");
        $stmt->bind_param("ss", $username, $hashed_password);

        // Execute and check for success
        if ($stmt->execute()) {
            $successMessage = "Registration successful! Admin account has been created.";
            header("Location: ../login/login.php"); // Redirect to admin dashboard or similar
            exit();
        } else {
            $errors['general'] = "Error: " . $stmt->error;
        }

        $stmt->close();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Register</title>
    <link rel="stylesheet" href="./admin_register.css"> <!-- Add your own CSS for admin registration -->
    <style>
        .logo {
            max-width: 100px;
            margin-bottom: 20px;
        }
        .header {
            display: flex;
            align-items: center;
            margin-bottom: 20px;
        }
        .message {
            margin-bottom: 20px;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <img src="./../assets/images/Logo.png" alt="Logo" class="logo">
            <h2>Admin Registration</h2>
        </div>

        <?php if (!empty($errors) || !empty($successMessage)): ?>
        <div class="message">
            <?php if (!empty($successMessage)): ?>
            <div class="success-message"><?php echo $successMessage; ?></div>
            <?php endif; ?>
            <?php if (!empty($errors)): ?>
            <ul>
                <?php foreach ($errors as $error): ?>
                <li class="error-message"><?php echo $error; ?></li>
                <?php endforeach; ?>
            </ul>
            <?php endif; ?>
        </div>
        <?php endif; ?>

        <form action="admin_register.php" method="post">
            <label for="username">Username:</label>
            <input type="text" name="username" value="<?php echo htmlspecialchars($username); ?>"
                class="<?php echo $borderClass['username']; ?>" required>

            <label for="password">Password:</label>
            <input type="password" name="password" class="<?php echo $borderClass['password']; ?>" required>

            <label for="confirmPassword">Confirm Password:</label>
            <input type="password" name="confirmPassword" class="<?php echo $borderClass['confirmPassword']; ?>"
                required>

            <button type="submit">Register</button>
        </form>

        <div class="already-registered">
            <p>Already registered? <a href="../login/login.php">Log in here</a>.</p>
        </div>
    </div>
</body>
</html>
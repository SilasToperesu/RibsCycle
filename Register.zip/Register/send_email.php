<?php
require '../vendor/autoload.php'; // Adjust path as necessary

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

function sendVerificationEmail($to, $verification_link) {
    $mail = new PHPMailer(true);
    
    try {
        $mail->isSMTP();
        $mail->Host = 'smtp-relay.brevo.com';
        $mail->SMTPAuth = true;
        $mail->Username = '7f29d2001@smtp-brevo.com'; // Replace with your email
        $mail->Password = 'XNC3rAtFd4GHjJ6x'; // Replace with your email password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom('khanyisilemoticoe@gmail.com', 'Ribs Circle'); // Set a valid from address
        $mail->addAddress($to);
        
        $mail->isHTML(true);
        $mail->Subject = 'Email Verification';
        $mail->Body    = 'Click the link to verify your account: <a href="' . $verification_link . '">Verify my account</a>';
        $mail->AltBody = 'Click the link to verify your account: ' . $verification_link;

        // Enable verbose debug output (for testing purposes; you can set this to 0 to disable)
        $mail->SMTPDebug = 2; 

        $mail->send();
        return true; // Email sent successfully
    } catch (Exception $e) {
        echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}"; // Output the error
        return false; // Email could not be sent
    }
}

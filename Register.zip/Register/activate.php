<?php
require '../vendor/autoload.php'; // Adjust path as necessary

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Function to send verification email
function sendVerificationEmail($to, $verification_link) {
    $mail = new PHPMailer(true);
    
    try {
        $mail->isSMTP();
        $mail->Host = 'smtp-relay.brevo.com';
        $mail->SMTPAuth = true;
        $mail->Username = '7f29d2001@smtp-brevo.com'; // Replace with your email
        $mail->Password = 'XNC3rAtFd4GHjJ6x'; // Replace with your email password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom('khanyisilemoticoe@gmail.com', 'Ribs Circle'); // Set a valid from address
        $mail->addAddress($to);
        
        $mail->isHTML(true);
        $mail->Subject = 'Email Verification';
        $mail->Body    = 'Click the link to verify your account: <a href="' . $verification_link . '">Verify my account</a>';
        $mail->AltBody = 'Click the link to verify your account: ' . $verification_link;

        // Enable verbose debug output (for testing purposes)
        $mail->SMTPDebug = 2; 

        $mail->send();
        return true; // Email sent successfully
    } catch (Exception $e) {
        return false; // Email could not be sent
    }
}

// Check for AJAX request to resend the email
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the JSON data from the request body
    $data = json_decode(file_get_contents('php://input'), true); // Decode JSON

    // Check if email key exists
    if (isset($data['email'])) {
        $userEmail = $data['email']; // Get the email from the decoded JSON
        $verification_link = 'http://yourwebsite.com/verify.php?token=someRandomToken'; // Adjust the verification link

        // Send the email
        if (sendVerificationEmail($userEmail, $verification_link)) {
            echo json_encode(['success' => true, 'message' => 'Verification email has been resent.']);
        } else {
            echo json_encode(['success' => false, 'message' => 'Failed to send verification email.']);
        }
    } else {
        echo json_encode(['success' => false, 'message' => 'Email not provided.']);
    }
    exit; // Terminate script after handling AJAX request
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Activate Your Account</title>
    <style>
        /* Add your CSS styles here */
        body {
            font-family: Arial, sans-serif;
            background-color: #f5f5f5;
            color: #333;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }
        .container {
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            padding: 40px;
            text-align: center;
            width: 300px;
        }
        h1 {
            color: #3d0101;
            margin-bottom: 20px;
            font-size: 22px;
        }
        p {
            margin-bottom: 20px;
            line-height: 1.6;
        }
        .button {
            display: inline-block;
            padding: 10px 20px;
            background-color: #3d0101; /* Button background color */
            color: white;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .button:hover {
            background-color: #5c0a0a; /* Darker shade on hover */
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Account Activation Required</h1>
        <p>Hello, User!</p>
        <p>Thank you for registering. To activate your account, please check your email and click on the activation link.</p>
        <p>If you don't see the email, please check your spam folder.</p>
    
    </div>

    <script>
        // Function to resend the verification email
        document.getElementById('resendButton').addEventListener('click', function() {
            const email = localStorage.getItem('userEmail'); // Get the email from local storage
            if (!email) {
                alert("Email not found in localStorage. Please register again.");
                return;
            }

            // Send AJAX request to the server
            fetch('activate.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ email: email }), // Send the email to the PHP script
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    alert(data.message); // Show success message
                } else {
                    alert(data.message); // Show error message
                }
            })
            .catch(error => {
                console.error('Error:', error);
            });
        });
    </script>
</body>
</html>
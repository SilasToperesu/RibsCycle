<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Ribs Circle - Gallery</title>
    <link rel="stylesheet" href="style.css"> <!-- Make sure to include your main styles -->
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f8f9fa;
        }
        header {
            background-color: #3d0101; /* Change header color */
            color: white;
            padding: 10px 20px;
            text-align: center;
            position: relative;
        }

        h1 {
            margin: 0;
        }

        .gallery-container {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(300px, 1fr)); /* Responsive grid */
            gap: 15px;
            padding: 20px;
        }

        .gallery-item {
            position: relative;
            overflow: hidden;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s;
        }

        .gallery-item img, .gallery-item video {
            width: 100%;
            height: auto;
            border-radius: 10px;
        }

        .gallery-item:hover {
            transform: scale(1.05); /* Scale effect on hover */
        }

        /* Specific styles for the larger Customers image */
        .large-image {
            grid-column: span 2; /* Make this image span across 2 columns */
            grid-row: span 4;    /* Makes the image take up more height */
            margin-bottom: 15px; /* Space below the large image */
        
        }

        /* Lightbox */
        .lightbox {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.8);
            justify-content: center;
            align-items: center;
            z-index: 1000;
        }

        .lightbox img, .lightbox video {
            max-width: 90%;
            max-height: 90%;
        }

        .close {
            position: absolute;
            top: 20px;
            right: 30px;
            color: white;
            font-size: 30px;
            cursor: pointer;
        }
    </style>
</head>
<body>
<?php include '../header.php'; ?>
    <header>
        <h1>Gallery</h1>
    </header>

    <div class="gallery-container">
        <!-- Add images and videos here -->
        <div class="gallery-item">
            <img src="gallery_images/img1.jpg" alt="Gallery Image 1" onclick="openLightbox(this.src)">
        </div>
        <div class="gallery-item">
            <video controls>
                <source src="gallery_images/vid1.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
        </div>
        <div class="gallery-item">
            <img src="gallery_images/img2.jpg" alt="Gallery Image 2" onclick="openLightbox(this.src)">
        </div>
        <div class="gallery-item">
            <video controls>
                <source src="gallery_images/vid2.mp4" type="video/mp4">
                Your browser does not support the video tag.
            </video>
        </div>
        <div class="gallery-item large-image">
            <img src="gallery_images/Customers.jpg" alt="Gallery Image 4" onclick="openLightbox(this.src)">
        </div>
        <div class="gallery-item">
            <img src="gallery_images/Community.jpg" alt="Gallery Image 3" onclick="openLightbox(this.src)">
        </div>
        <!-- More images and videos can be added here -->
    </div>

    <!-- Lightbox for images -->
    <div id="lightbox" class="lightbox" onclick="closeLightbox()">
        <span class="close" onclick="closeLightbox()">&times;</span>
        <img id="lightboxImg" src="" alt="">
        <video id="lightboxVideo" controls style="display:none;"></video>
    </div>

    <script>
        function openLightbox(src) {
            const lightbox = document.getElementById('lightbox');
            const lightboxImg = document.getElementById('lightboxImg');
            const lightboxVideo = document.getElementById('lightboxVideo');

            // Check if the source is an image or video based on the file extension
            if(src.endsWith('.mp4')) {
                lightboxImg.style.display = 'none';
                lightboxVideo.style.display = 'block';
                lightboxVideo.src = src;
                lightboxVideo.play();
            } else {
                lightboxImg.style.display = 'block';
                lightboxVideo.style.display = 'none';
                lightboxImg.src = src;
            }

            lightbox.style.display = 'flex'; // Show the lightbox
        }

        function closeLightbox() {
            const lightbox = document.getElementById('lightbox');
            const lightboxVideo = document.getElementById('lightboxVideo');

            lightbox.style.display = 'none'; // Hide the lightbox
            lightboxVideo.pause(); // Pause the video
            lightboxVideo.src = ''; // Clear video source
        }
    </script>
</body>
</html>
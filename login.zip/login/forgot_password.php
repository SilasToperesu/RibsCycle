<?php
// forgot_password.php
include '../db_connect.php'; // Include your database connection
require '../vendor/autoload.php'; // Load PHPMailer

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$errors = [];
$email = '';
$successMessage = '';

function sendVerificationEmail($to, $reset_link) {
    $mail = new PHPMailer(true);
    
    try {
        $mail->isSMTP();
        $mail->Host = 'smtp-relay.brevo.com';
        $mail->SMTPAuth = true;
        $mail->Username = '7f29d2001@smtp-brevo.com'; // Replace with your email
        $mail->Password = 'XNC3rAtFd4GHjJ6x'; // Replace with your email password
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom('khanyisilemoticoe@gmail.com', 'Ribs Circle'); // Set a valid from address
        $mail->addAddress($to);
        
        $mail->isHTML(true);
        $mail->Subject = 'Password Reset';
        $mail->Body    = 'Click the link to reset your password: <a href="' . $reset_link . '">Reset my password</a>';
        $mail->AltBody = 'Click the link to reset your password: ' . $reset_link;

        $mail->send();
        return true;
    } catch (Exception $e) {
        return false;
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = trim($_POST['email']);

    if (empty($email)) {
        $errors['email'] = "Please enter your email address.";
    } elseif (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors['email'] = "Please enter a valid email address.";
    }

    if (empty($errors)) {
        $stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $stmt->store_result();

        if ($stmt->num_rows === 1) {
            $token = bin2hex(random_bytes(32));
            $expires_at = date('Y-m-d H:i:s', strtotime('+1 hour'));

            $stmt_insert = $conn->prepare("REPLACE INTO password_resets (email, token, expires_at) VALUES (?, ?, ?)");
            $stmt_insert->bind_param("sss", $email, $token, $expires_at);
            $stmt_insert->execute();
            $stmt_insert->close();

            $reset_link = "http://localhost/RibsCircle_System/login/reset_password.php?token=" . $token . "&email=" . urlencode($email);

            if (sendVerificationEmail($email, $reset_link)) {
                $successMessage = "A reset link has been sent to your email.";
            } else {
                $errors['email'] = "Failed to send the email. Please try again.";
            }
        } else {
            $errors['email'] = "No account found with that email address.";
        }

        $stmt->close();
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Forgot Password</title>
    <link rel="stylesheet" href="logStyle.css">
</head>
<body>
    <div class="container">
        <h2>Forgot Password</h2>
        
        <?php if (!empty($errors)): ?>
            <ul>
                <?php foreach ($errors as $error): ?>
                    <li style="color: red;"><?php echo $error; ?></li>
                <?php endforeach; ?>
            </ul>
        <?php elseif (!empty($successMessage)): ?>
            <div style="color: green;"><?php echo $successMessage; ?></div>
        <?php endif; ?>

        <form action="forgot_password.php" method="post">
            <label for="email">Enter your email address:</label>
            <input type="email" name="email" value="<?php echo htmlspecialchars($email); ?>" required>
            <button type="submit">Send Reset Link</button>
        </form>
        
        <div>
            <a href="login.php">Back to Login</a>
        </div>
    </div>
</body>
</html>

<?php
// Start the session or include any necessary authentication checks.
session_start();

// Assuming you have a verification check here
// e.g., if user is successfully verified, show the message
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Account Verified</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            text-align: center;
            background-color: white;
            padding: 50px;
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
        }
        .tick {
            display: inline-block;
            font-size: 100px; /* Adjust size of the tick */
            color: white; /* Color of the tick */
            background-color: green; /* Background color of the tick */
            border-radius: 50%; /* Make it circular */
            width: 150px; /* Diameter of the circle */
            height: 150px; /* Diameter of the circle */
            line-height: 150px; /* Center align the tick vertically */
            text-align: center; /* Center align the tick horizontally */
            margin: 0 auto 20px; /* Center the tick */
        }
        .login-link {
            text-decoration: none;
            color: #007BFF; /* Link color */
            font-size: 18px; /* Link font size */
            margin-top: 10px;
            display: inline-block;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="tick">✔️</div>
        <h1>Account Verified!</h1>
        <p>Your account has been successfully verified.</p>
        <a href="./login.php" class="login-link">Go to Login</a>
    </div>
</body>
</html>
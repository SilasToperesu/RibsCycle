<?php
// reset_password.php
include '../db_connect.php';

$errors = [];
$email = $_GET['email'] ?? '';
$token = $_GET['token'] ?? '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Handle the password reset process
    $email = $_POST['email'] ?? '';
    $password = $_POST['password'] ?? '';
    $token = $_POST['token'] ?? '';

    // Validate the password
    if (strlen($password) < 6) {
        $errors[] = "Password must be at least 6 characters.";
    }

    // Validate the email format
    if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = "Invalid email address.";
    }

    if (empty($errors)) {
        // Validate token and email
        $stmt = $conn->prepare("SELECT expires_at FROM password_resets WHERE email = ? AND token = ?");
        $stmt->bind_param("ss", $email, $token);
        $stmt->execute();
        $stmt->bind_result($expires_at);
        $stmt->fetch();
        $stmt->close();

        if (!$expires_at || strtotime($expires_at) < time()) {
            $errors[] = "Invalid or expired reset link.";
        } else {
            // Update password in the users table
            $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("UPDATE users SET password = ? WHERE email = ?");
            $stmt->bind_param("ss", $hashedPassword, $email);
            $stmt->execute();
            $stmt->close();

            // Remove the token from the password_resets table
            $stmt = $conn->prepare("DELETE FROM password_resets WHERE email = ? AND token = ?");
            $stmt->bind_param("ss", $email, $token);
            $stmt->execute();
            $stmt->close();

            // Redirect to the login page with a success message
            echo "<script>
                    alert('Password has been reset successfully.');
                    window.location.href = 'login.php';
                  </script>";
            exit;
        }
    }
}

// If email and token are set, validate them and show the reset form
if ($email && $token) {
    // Query to check if the email and token exist and are valid
    $stmt = $conn->prepare("SELECT expires_at FROM password_resets WHERE email = ? AND token = ?");
    $stmt->bind_param("ss", $email, $token);
    $stmt->execute();
    $stmt->bind_result($expires_at);
    $stmt->fetch();
    $stmt->close();

    // If the token or email doesn't exist or has expired
    if (!$expires_at) {
        $errors[] = "Invalid reset link.";
    } elseif (strtotime($expires_at) < time()) {
        $errors[] = "This reset link has expired.";
    }
} else {
    $errors[] = "Invalid request.";
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Reset Password</title>
    <link rel="stylesheet" href="logStyle.css">
    <script>
        // JavaScript to handle localStorage email and populate form
        window.onload = function() {
            const emailFromURL = new URLSearchParams(window.location.search).get('email');
            const storedEmail = localStorage.getItem('resetEmail');

            // Store email from URL in localStorage if not already stored
            if (emailFromURL) {
                localStorage.setItem('resetEmail', emailFromURL);
            }

            if (storedEmail) {
                // Autofill the email field with the stored email
                document.getElementById('emailInput').value = storedEmail;
            } else {
                alert('Email not found in localStorage.');
                window.location.href = 'login.php';  // Redirect if email is missing
            }
        };
    </script>
</head>
<body>
    <div class="container">
        <h2>Reset Password</h2>

        <?php if (!empty($errors)): ?>
            <ul>
                <?php foreach ($errors as $error): ?>
                    <li style="color: red;"><?php echo $error; ?></li>
                <?php endforeach; ?>
            </ul>
        <?php else: ?>
            <form action="reset_password.php" method="post">
                <!-- Hidden fields to pass token and email to the handler -->
                <input type="hidden" name="token" value="<?php echo htmlspecialchars($token); ?>">

                <!-- Email field (readonly) -->
                <label for="emailInput">Email:</label>
                <input type="email" id="emailInput" name="email" required readonly>

                <!-- New password field -->
                <label for="password">New Password:</label>
                <input type="password" name="password" required>
                <button type="submit">Reset Password</button>
            </form>
        <?php endif; ?>

        <div>
            <a href="login.php">Back to Login</a>
        </div>
    </div>
</body>
</html>
